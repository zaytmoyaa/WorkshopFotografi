# Workshop Fotografi

Proyek Android sederhana untuk tugas praktikum tema 13: **Pendaftaran Workshop Fotografi**. Proyek ini dibuat dengan Java dan XML agar mudah dipahami untuk pembelajaran dasar Android Studio.

## Fitur yang sesuai tugas

- Halaman utama memakai `LinearLayout` pada bagian header dan form.
- Input nama lengkap sebagai data `String`.
- Input usia dengan `inputType="number"` sebagai data `Integer`.
- Validasi kolom kosong menggunakan `setError()` dan `Toast`.
- Validasi usia angka yang valid dan tidak negatif.
- **Explicit Intent** ke `FormActivity`, mengirim nama dan usia.
- **Implicit Intent** untuk membuka informasi event di browser/Instagram.
- Halaman hasil memakai `ConstraintLayout`, menerima data dengan `getStringExtra()` dan `getIntExtra()`.
- Tombol kembali menggunakan `finish()`.

## Cara membuka di Android Studio

1. Buka Android Studio.
2. Pilih **Open** lalu pilih folder `WorkshopFotografi` ini.
3. Tunggu proses Gradle Sync selesai.
4. Pilih emulator atau perangkat Android, lalu tekan **Run**.

## Skenario pengujian singkat

1. Tekan **Kirim Data ke Form** saat dua input kosong. Pastikan muncul error dan Toast.
2. Isi nama `Budi Santoso` dan usia `19`, lalu tekan tombol kirim. Pastikan halaman kedua menampilkan pesan pendaftaran berhasil.
3. Tekan **Kembali ke Menu Utama**. Pastikan kembali ke halaman pertama.
4. Tekan **Buka Info Event**. Pastikan browser atau aplikasi Instagram terbuka.

## Mengunggah ke GitHub

Sesudah membuat repository kosong di akun GitHub, jalankan perintah berikut dari folder proyek:

```bash
git init
git add .
git commit -m "Membuat aplikasi pendaftaran workshop fotografi"
git branch -M main
git remote add origin https://github.com/zaytmoyaa/WorkshopFotografi.git
git push -u origin main
```

Repository tugas ini: https://github.com/zaytmoyaa/WorkshopFotografi
