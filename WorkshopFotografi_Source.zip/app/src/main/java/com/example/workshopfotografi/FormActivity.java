package com.example.workshopfotografi;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class FormActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form);

        TextView teksHasil = findViewById(R.id.teks_hasil);
        Button tombolKembali = findViewById(R.id.tombol_kembali);

        // Menerima String dan Integer dari MainActivity.
        String nama = getIntent().getStringExtra(MainActivity.EXTRA_NAMA);
        int usia = getIntent().getIntExtra(MainActivity.EXTRA_USIA, -1);

        if (nama == null || nama.trim().isEmpty() || usia < 0) {
            Toast.makeText(this, R.string.toast_data_tidak_ditemukan, Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        teksHasil.setText(getString(R.string.pesan_berhasil, nama, usia));
        tombolKembali.setOnClickListener(view -> finish());
    }
}
