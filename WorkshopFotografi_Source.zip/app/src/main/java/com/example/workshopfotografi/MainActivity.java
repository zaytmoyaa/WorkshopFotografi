package com.example.workshopfotografi;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {

    public static final String EXTRA_NAMA = "com.example.workshopfotografi.NAMA";
    public static final String EXTRA_USIA = "com.example.workshopfotografi.USIA";

    private EditText inputNama;
    private EditText inputUsia;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputNama = findViewById(R.id.input_nama);
        inputUsia = findViewById(R.id.input_usia);
        Button tombolKirim = findViewById(R.id.tombol_kirim);
        Button tombolInfo = findViewById(R.id.tombol_info);

        tombolKirim.setOnClickListener(view -> kirimDataKeForm());
        tombolInfo.setOnClickListener(view -> bukaInfoEvent());
    }

    private void kirimDataKeForm() {
        String nama = inputNama.getText().toString().trim();
        String usiaTeks = inputUsia.getText().toString().trim();
        boolean dataValid = true;

        if (nama.isEmpty()) {
            inputNama.setError(getString(R.string.error_nama_kosong));
            dataValid = false;
        }

        if (usiaTeks.isEmpty()) {
            inputUsia.setError(getString(R.string.error_usia_kosong));
            dataValid = false;
        }

        if (!dataValid) {
            Toast.makeText(this, R.string.toast_data_belum_lengkap, Toast.LENGTH_SHORT).show();
            return;
        }

        int usia;
        try {
            usia = Integer.parseInt(usiaTeks);
        } catch (NumberFormatException e) {
            inputUsia.setError(getString(R.string.error_usia_tidak_valid));
            Toast.makeText(this, R.string.toast_usia_tidak_valid, Toast.LENGTH_SHORT).show();
            return;
        }

        if (usia < 0) {
            inputUsia.setError(getString(R.string.error_usia_negatif));
            Toast.makeText(this, R.string.toast_usia_tidak_valid, Toast.LENGTH_SHORT).show();
            return;
        }

        // Explicit Intent: mengirim String nama dan Integer usia ke FormActivity.
        Intent intent = new Intent(MainActivity.this, FormActivity.class);
        intent.putExtra(EXTRA_NAMA, nama);
        intent.putExtra(EXTRA_USIA, usia);
        startActivity(intent);
    }

    private void bukaInfoEvent() {
        // Implicit Intent untuk membuka halaman Instagram bertema fotografi.
        Intent intent = new Intent(Intent.ACTION_VIEW,
                Uri.parse(getString(R.string.url_info_event)));

        try {
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, R.string.toast_browser_tidak_ada, Toast.LENGTH_SHORT).show();
        }
    }
}
